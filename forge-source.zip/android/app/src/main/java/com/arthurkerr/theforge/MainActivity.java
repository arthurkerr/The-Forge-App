package com.arthurkerr.theforge;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
